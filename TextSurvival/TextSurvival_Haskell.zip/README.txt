Basic Text Survival Game
Yunyi Ding yding13
Brian Lin bjlin

Haskell code: TextSurvival.hs
Run command "ghc --make TextSurvival" and run the program with "TextSurvival" (if that doesn't work then try "./TextSurvival")