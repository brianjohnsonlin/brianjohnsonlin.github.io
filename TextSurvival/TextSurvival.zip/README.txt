Basic Text Survival Game
Yunyi Ding yding13
Brian Lin bjlin

Haskell code: TextSurvival.hs
Run command "ghc --make TextSurvival" and run the program with "TextSurvival" (if that doesn't work then try "./TextSurvival")

JavaScript code: TextSurvival.js, TextSurvival.html
Opening the HTML file in the web browser of your choice will run the game. The js file has to be in the same directory as the html file and should not be renamed.